import React, { useState } from 'react';
import { useNavigate } from "react-router-dom";

import "./login.css";

export const LoginForm = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    // Perform login logic and handle errors
    if (username === 'admin' && password === '1234567') {
      // Successful login, redirect or perform other actions
      console.log('Login successful!');
    } else {
      setError('Invalid credentials');
    }
  };

  return (
    <div className='body'>
    <form onSubmit={handleLogin}>
      <h2>Login</h2>
      <div>
        <label>Username:</label>
        <input
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
      </div>
      <div>
        <label>Password:</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      {error && <p>{error}</p>}
      <button type="submit">Login</button>
    </form>
    </div>
  );
};
const Login = () => {
    return (
      <div>
        <LoginForm />
      </div>
    );
};


