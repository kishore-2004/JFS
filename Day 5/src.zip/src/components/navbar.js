import React from "react";
import { Link } from "react-router-dom";
// import { ShoppingCart } from "phosphor-react";
import "./navbar.css";
import AccountMenu from "./accountmenu";


export const Navbar = () => {
  return (
    <div className="navbar">
    <div className="link">
    <Link to="/home"> Home </Link>
    <a href="#">Movie</a>
    {/* <Link to="/home"> movie </Link> */}
    <Link to="/concert"> Concert </Link>
    <Link to="/offers"> Offer </Link>

    <Link to="/contact"> Contact </Link>
    </div>
      <div className="links"> 
        </div>
        <div>
       <AccountMenu />
       </div>
      </div>
  );
};